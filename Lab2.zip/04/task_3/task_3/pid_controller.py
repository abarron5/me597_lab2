import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32 
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
import math
import time

class PID_control(Node):
    def __init__(self):
        super().__init__('pid_speed_controller')

        # Desired response specs
        self.desired_overshoot = 0.15    # 15%
        self.desired_settling_time = 30  # seconds
        self.target_dist = 0.35          # meters

        # Second-order system relations
        self.damping_ratio = (-1 * (math.log(self.desired_overshoot))) / math.sqrt(math.pi**2 + (math.log(self.desired_overshoot))**2)
        self.natural_frequency = 4 / (self.damping_ratio * self.desired_settling_time)

        # PID gains (can be tuned from system params)
        self.kp = .28
        self.ki = 0.001
        self.kd = 0.2

        # integrator anti-windup limits
        self.integral = 0.0
        self.integral_min = -0.5
        self.integral_max = 0.5

        # PID state
        self.prev_error = 0.0
        self.integral = 0.0
        self.prev_time = time.time()

        # Step response tracking
        self.start_time = time.time()
        self.min_error = float("inf")
        self.settled = False
        self.settling_time = None

        # ROS pubs/subs
        self.subscription = self.create_subscription(
            LaserScan,
            '/scan',
            self.listener_callback,
            10)
        
        self.publisher = self.create_publisher(Twist, 'cmd_vel', 10)

        self.get_logger().info("PID Distance Controller Node Started")


    def listener_callback(self, msg):
        # Get forward-facing distance
        forward_idx = 0
        distance = msg.ranges[forward_idx]

        # Compute error
        error = distance - self.target_dist
        current_time = time.time()
        dt = current_time - self.prev_time if current_time - self.prev_time > 0 else 1e-6

        # --- PID control ---
        # Integral with anti-windup: only integrate if actuator not saturated OR integral will help
        self.integral += error * dt
        # clamp integral
        if self.integral > self.integral_max:
            self.integral = self.integral_max
        elif self.integral < self.integral_min:
            self.integral = self.integral_min

        derivative = (error - self.prev_error) / dt
        control = (self.kp * error) + (self.ki * self.integral) + (self.kd * derivative)

        # Limit control signal
        control = max(min(control, 0.15), -0.15)

        # Publish velocity
        twist = Twist()
        twist.linear.x = control
        self.publisher.publish(twist)

        # --- Overshoot Calculation ---
        if error < self.min_error:
            self.min_error = error

        overshoot = 0.0
        if self.target_dist != 0:
            overshoot = min(0.0, self.min_error / self.target_dist)

        # --- Settling Time Calculation ---
        tolerance = 0.02 * self.target_dist  # 2% band
        if not self.settled:
            if abs(error) <= tolerance:
                # Check if it stays inside tolerance for a while
                if self.settling_time is None:
                    self.settling_time = current_time - self.start_time
                else:
                    self.settled = True

        # --- Logging ---
        self.get_logger().info(
            f"Distance: {distance:.3f}, Error: {error:.3f}, Control: {control:.3f}"
        )
        #self.get_logger().info(
        #    f"kp: {self.kp:.3f}, ki: {self.ki:.3f}, kd: {self.kd:.3f}"
        #)
        self.get_logger().info(
            f"Overshoot: {overshoot*-100:.2f}%, Settling Time: {self.settling_time if self.settling_time else 'N/A'} s"
        )

        # Update state
        self.prev_error = error
        self.prev_time = current_time


def main(args=None):
    rclpy.init(args=args)
    pid_speed_controller = PID_control()
    rclpy.spin(pid_speed_controller)
    pid_speed_controller.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
